//
//  KWApp.h
//  KuaikanSDK
//
//  Created by DengShuo on 18/04/2017.
//  Copyright © 2017 Kuaikan World (Beijing) Technology Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/*
 *   @brief  初始化入口
 */
@class KWAuth;

@interface KWApp : NSObject

+ (void) launchWithAppId:(NSString*)appId options:(NSDictionary *_Nullable)options;

- (instancetype)init NS_UNAVAILABLE;

+ (KWApp *)app;

@property (nonatomic, strong, readonly) KWAuth *_Nullable auth;

@property (nonatomic, strong, readonly, nullable) NSString* appId;

+ (BOOL)kw_application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(nullable NSString *)sourceApplication annotation:(id)annotation NS_DEPRECATED_IOS(4_2, 9_0, "Please use kw_application:openURL:options:") __TVOS_PROHIBITED;
+ (BOOL)kw_application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey, id> *)options NS_AVAILABLE_IOS(9_0); // no equiv. notification. return NO if the application can't open for some reason

@end

NS_ASSUME_NONNULL_END
