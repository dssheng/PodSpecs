//
//  KWUIManager.h
//  KuaikanSDK
//
//  Created by zhanqijie on 2017/5/3.
//  Copyright © 2017年 Kuaikan World (Beijing) Technology Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol KWUIManagerDelegate <NSObject>

@optional

/**  
 手机登录接口返回
 */
- (void)KWLoginCompletion:(NSString *)session error:(NSError *)error;

- (void)KWCommonCompletion:(BOOL)ret error:(NSError *)error;

@end

@interface KWUIManager : NSObject

@property (nonatomic, weak)id <KWUIManagerDelegate>delegate;

+ (instancetype)shareInstance;

- (void)popView:(UIView *)popView;

- (void)hidePopView;

- (void)showLoginView;

- (void)showOAuthView;

- (void)showVisitorLoginView;

- (void)showRegisterView;

- (void)showRePassword;

- (void)showBindPhone;

- (void)showPersonalView;

@end
