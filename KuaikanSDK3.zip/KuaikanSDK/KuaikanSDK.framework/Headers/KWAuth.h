//
//  KWAuth.h
//  KuaikanSDK
//
//  Created by DengShuo on 13/04/2017.
//  Copyright © 2017 Kuaikan World (Beijing) Technology Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@class KWUser;

NS_ASSUME_NONNULL_BEGIN

typedef void(^KWCommonCallback)(BOOL ret, NSError *_Nullable error);

typedef void(^KWSmartLoginCallback)(KWUser *_Nullable user, NSError *_Nullable error);
typedef void(^KWLoginCallback)(NSString *_Nullable session, NSError *_Nullable error);
typedef void(^KWAuthLoginCallback)(NSString* openId, NSString* accessToken, KWUser *_Nullable user, BOOL isNewAccount, NSError *_Nullable error);
typedef void(^KWVisitorLoginCallback)(KWUser *_Nullable user, NSString* accessToken, BOOL isNewAccount, NSError *_Nullable error);

//typedef void(^KWVerifyOpenIdCallback)(BOOL ret, NSError *_Nullable error);
typedef void(^KWVerifyCodeCallback)(NSString* verifyToken, BOOL isRegsiter, NSError *_Nullable error);
typedef void(^KWRegsiterCallback)(NSString* verifyToken, NSError *_Nullable error);
typedef void(^KWGetUserInfoCallback)(KWUser *_Nullable user, NSError *_Nullable error);


@interface KWAuth : NSObject

@property (nonatomic, readonly) NSString* openId;
@property (nonatomic, readonly) NSString* accessToken;

/*
 @brief using auth or authWithAppId;
 */
- (instancetype)init NS_UNAVAILABLE;

+ (nullable KWAuth*)auth;


/**  @brief 自动区分未注册／已注册用户，并进行登录。username（phone） & password 不为空时，使用username和password登录，否则使用当前已经登录的用户
 */
- (void)smartLoginWithUsername:(NSString *_Nullable) username
                      password:(NSString *_Nullable) password
                    completion:(KWSmartLoginCallback)completion;

/**  @brief 手机登录接口
 */
- (void)loginWithPhone:(NSString *)phoneNumber
              password:(NSString *)password
            completion:(KWLoginCallback)completion;

/**  @brief 授权接口
 */
- (void)authLoginCompletion:(KWAuthLoginCallback)completion;

/**  @brief verify open ID
 */
- (void)verifyOpenId:(NSString *)openId
         accessToken:(NSString *)accessToken
                sign:(NSString *_Nullable)signString
          completion:(KWCommonCallback)completion;

/**  @brief 游客登录
 */
- (void)visitorLoginCompletion:(KWVisitorLoginCallback)completion;

/** @brief 绑定游客和手机
 */
- (void)visitorBindPhone:(NSString*)phone
                  openId:(NSString*)openId
                password:(NSString*)password
             verifyToken:(NSString *)verifyToken
              completion:(KWCommonCallback)completion;


typedef enum : NSUInteger {
    KWSMS_Register      = 2,
    KWSMS_FindPassword  = 3,
    KWSMS_Bind          = 4,
} KWSMSType;
/** @fn TODO
 @brief 请求验证码
 */
- (void)requestVerifyCodeWithPhone:(NSString *)phone
                          codeType:(KWSMSType)codeType
                        completion:(KWCommonCallback)completion;


/** @fn TODO
 @brief 验证验证码
 */
- (void)verifyCodeWithPhone:(NSString *)phone
                    smsCode:(NSString *)smsCode
                 completion:(KWVerifyCodeCallback)completion;

/** @fn TODO
 @brief 新用户注册
 */
- (void)registerWithPhone:(NSString *)phone
                 password:(NSString *)password
              verifyToken:(NSString *)verifyToken
               completion:(KWRegsiterCallback)completion;


/** @fn TODO
 @brief 找回密码
 */
- (void)resetPasswordWithPhone:(NSString *)phone
                      password:(NSString *)password
                   verifyToken:(NSString *)verifyToken
                    completion:(KWCommonCallback)completion;

/** @fn TODO
 @brief 获取用户信息
 */
- (void)getUserInfoWithAccessToken:(NSString *)accessToken
                        completion:(KWGetUserInfoCallback)completion;

/** @fn TODO
 @brief 登录日志
 */
- (void)loginStatWithOpenId:(NSString *)openId
                       role:(NSString *)role
              authorizeType:(NSString *)authorizeType
             firstTimeLogin:(BOOL)isFirstTimeLogin;


@end


NS_ASSUME_NONNULL_END
