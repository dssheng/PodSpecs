//
//  KuaikanSDK.h
//  KuaikanSDK
//
//  Created by DengShuo on 13/04/2017.
//  Copyright © 2017 Kuaikan World (Beijing) Technology Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KuaikanSDK.
FOUNDATION_EXPORT double KuaikanSDKVersionNumber;

//! Project version string for KuaikanSDK.
FOUNDATION_EXPORT const unsigned char KuaikanSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KuaikanSDK/PublicHeader.h>

#import <KuaikanSDK/KWApp.h>
#import <KuaikanSDK/KWAuth.h>
#import <KuaikanSDK/KWUser.h>
#import <KuaikanSDK/KWUIManager.h>

