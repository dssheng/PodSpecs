//
//  KWUser.h
//  KuaikanSDK
//
//  Created by DengShuo on 13/04/2017.
//  Copyright © 2017 Kuaikan World (Beijing) Technology Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KWUser : NSObject

@property (nonatomic, strong) NSString* openId;
@property (nonatomic, strong) NSString* accessToken;
@property (nonatomic, strong) NSString* nickname;
@property (nonatomic, strong) NSString* avatorUrl;

+ (instancetype)createWithDict:(NSDictionary*)dict;

+ (KWUser*)getCurrentUser;
+ (BOOL)saveCurrentUser:(KWUser*)user;

@end
