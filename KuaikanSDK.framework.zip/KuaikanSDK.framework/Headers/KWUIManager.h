//
//  KWUIManager.h
//  KuaikanSDK
//
//  Created by zhanqijie on 2017/5/3.
//  Copyright © 2017年 Kuaikan World (Beijing) Technology Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface KWUIManager : NSObject

+ (instancetype)shareInstance;

- (void)popView:(UIView *)popView;

- (void)hidePopView;

+ (void)showLoginView;

+ (void)showOAuthView;

+ (void)showVisitorLoginView;

+ (void)showRegisterView;

+ (void)showRePassword;

+ (void)showBindPhone;

+ (void)showPersonalView;

@end
